package com.headsteal;

import com.headsteal.abilities.MobAbility;
import com.headsteal.abilities.*;
import com.headsteal.commands.HeadStealCmd;
import com.headsteal.events.HeadWearListener;
import com.headsteal.events.MobDeathListener;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public final class HeadSteal extends JavaPlugin {
    private static HeadSteal instance;
    private FileConfiguration config;
    private Map<String, MobAbility> mobAbilities;
    private HeadManager headManager;

    @Override
    public void onEnable() {
        instance = this;
        mobAbilities = new HashMap<>();
        
        // Save default config
        saveDefaultConfig();
        config = getConfig();
        
        // Initialize managers
        this.headManager = new HeadManager(this);
        
        // Register commands
        getCommand("headsteal").setExecutor(new HeadStealCmd(this));
        getCommand("soulbind").setExecutor(new SoulBindCommand());
        getCommand("soulrelease").setExecutor(new SoulReleaseCommand());
        getCommand("headability").setExecutor(new HeadAbilityCommand());
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new MobDeathListener(this), this);
        getServer().getPluginManager().registerEvents(new HeadWearListener(this), this);
        
        // Initialize abilities
        initializeAbilities();
        
        getLogger().info("HeadSteal has been enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("HeadSteal has been disabled!");
    }

    private void initializeAbilities() {
        // Hostile Mobs
        registerAbility("CREEPER", new CreeperAbility());
        registerAbility("ENDERMAN", new EndermanAbility());
        registerAbility("WITHER", new WitherAbility());
        registerAbility("BREEZE", new BreezeAbility());
        registerAbility("VEX", new VexAbility());
        
        // Passive Mobs
        registerAbility("COW", new CowAbility());
        registerAbility("FOX", new FoxAbility());
        registerAbility("AXOLOTL", new AxolotlAbility());
        registerAbility("CAMEL", new CamelAbility());
        
        // Neutral Mobs
        registerAbility("PANDA", new PandaAbility());
        registerAbility("DOLPHIN", new DolphinAbility());
        registerAbility("BEE", new BeeAbility());
        
        // Bosses & Special
        registerAbility("ENDER_DRAGON", new EnderDragonAbility());
        registerAbility("WARDEN", new WardenAbility());
        registerAbility("IRON_GOLEM", new IronGolemAbility());
    }

    private void registerAbility(String mobType, MobAbility ability) {
        mobAbilities.put(mobType, ability);
    }

    public static HeadSteal getInstance() {
        return instance;
    }

    public HeadManager getHeadManager() {
        return headManager;
    }

    public MobAbility getAbility(String mobType) {
        return mobAbilities.get(mobType);
    }
} 