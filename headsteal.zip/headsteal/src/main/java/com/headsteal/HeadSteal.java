package com.headsteal;

import com.headsteal.commands.HeadStealCmd;
import com.headsteal.events.HeadWearListener;
import com.headsteal.events.MobDeathListener;
import org.bukkit.plugin.java.JavaPlugin;

public final class HeadSteal extends JavaPlugin {
    private static HeadSteal instance;
    private HeadManager headManager;

    @Override
    public void onEnable() {
        instance = this;
        
        // Save default config
        saveDefaultConfig();
        
        // Initialize managers
        this.headManager = new HeadManager(this);
        
        // Register commands
        getCommand("headsteal").setExecutor(new HeadStealCmd(this));
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new MobDeathListener(this), this);
        getServer().getPluginManager().registerEvents(new HeadWearListener(this), this);
        
        getLogger().info("HeadSteal has been enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("HeadSteal has been disabled!");
    }

    public static HeadSteal getInstance() {
        return instance;
    }

    public HeadManager getHeadManager() {
        return headManager;
    }
} 