package com.headsteal.events;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import com.headsteal.HeadSteal;
import com.headsteal.HeadManager;

import java.util.Random;

public class MobDeathListener implements Listener {
    private final HeadSteal plugin;
    private final HeadManager headManager;
    private final Random random;

    public MobDeathListener(HeadSteal plugin) {
        this.plugin = plugin;
        this.headManager = plugin.getHeadManager();
        this.random = new Random();
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent event) {
        if (!(event.getEntity().getKiller() instanceof Player)) return;
        
        Player player = event.getEntity().getKiller();
        EntityType type = event.getEntityType();
        
        // Check if this mob type can drop heads
        if (!headManager.canDropHead(type)) return;
        
        // Calculate drop chance
        double baseChance = plugin.getConfig().getDouble("drop-chances." + type.name().toLowerCase(), 0.1);
        ItemStack weapon = player.getInventory().getItemInMainHand();
        
        // Apply looting bonus
        if (weapon != null && weapon.getType() != Material.AIR) {
            int lootingLevel = weapon.getEnchantmentLevel(Enchantment.LOOTING);
            baseChance += lootingLevel * 0.05; // 5% increase per looting level
        }
        
        // Roll for drop
        if (random.nextDouble() < baseChance) {
            headManager.dropHead(type, event.getEntity().getLocation());
        }
    }
} 