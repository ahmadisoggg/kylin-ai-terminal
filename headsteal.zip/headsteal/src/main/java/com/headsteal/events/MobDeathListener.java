package com.headsteal.events;

import com.headsteal.HeadSteal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;

public class MobDeathListener implements Listener {
    private final HeadSteal plugin;

    public MobDeathListener(HeadSteal plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        LivingEntity victim = event.getEntity();
        Entity killer = victim.getKiller();

        if (killer instanceof Player) {
            Player player = (Player) killer;
            
            // Check if player has permission
            if (!player.hasPermission("headsteal.collect")) {
                return;
            }

            // Get looting level
            ItemStack weapon = player.getInventory().getItemInMainHand();
            int lootingLevel = weapon.getEnchantmentLevel(org.bukkit.enchantments.Enchantment.LOOT_BONUS_MOBS);

            // Calculate drop chance
            double dropChance = plugin.getHeadManager().getDropChance(victim.getType(), lootingLevel);

            // Random check for drop
            if (Math.random() * 100 < dropChance) {
                plugin.getHeadManager().stealHead(victim, player);
            }
        }
    }
} 