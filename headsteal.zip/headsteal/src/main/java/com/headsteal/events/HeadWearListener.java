package com.headsteal.events;

import com.headsteal.HeadSteal;
import com.headsteal.abilities.AbilityManager;
import com.headsteal.clone.SkeletonCloneManager;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

public class HeadWearListener implements Listener {
    private final HeadSteal plugin;
    private final Map<UUID, Long> cooldowns;
    private final Map<UUID, String> wearingHeads;
    private final SkeletonCloneManager cloneManager;
    private final AbilityManager abilityManager;

    public HeadWearListener(HeadSteal plugin) {
        this.plugin = plugin;
        this.cooldowns = new HashMap<>();
        this.wearingHeads = new HashMap<>();
        this.cloneManager = new SkeletonCloneManager(plugin);
        this.abilityManager = new AbilityManager(plugin);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();

        if (item == null || !isHead(item)) return;

        String mobType = getMobTypeFromHead(item);
        if (mobType == null) return;

        if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            if (mobType.equals("skeleton")) {
                if (cloneManager.canCreateClone(player)) {
                    cloneManager.createClone(player);
                    abilityManager.playVisualEffects(player.getLocation(), mobType);
                }
            } else {
                wearHead(player, mobType);
            }
        } else if (event.getAction() == Action.LEFT_CLICK_AIR || event.getAction() == Action.LEFT_CLICK_BLOCK) {
            activateAbility(player, mobType);
        }
    }

    private void activateAbility(Player player, String mobType) {
        if (!abilityManager.canUseAbility(player, mobType, 1)) return;

        int cooldown = plugin.getConfig().getInt("abilities.cooldowns." + mobType, 30);
        if (isOnCooldown(player, cooldown)) {
            long remaining = (cooldowns.get(player.getUniqueId()) - System.currentTimeMillis()) / 1000;
            player.sendMessage(plugin.getConfig().getString("messages.ability-cooldown")
                    .replace("%time%", String.valueOf(remaining)));
            return;
        }

        abilityManager.applyCost(player, mobType, 1);
        abilityManager.playVisualEffects(player.getLocation(), mobType);

        switch (mobType.toLowerCase()) {
            case "creeper":
                // Suicide explosion (no self-damage)
                player.getWorld().createExplosion(player.getLocation(), 2.0f, false, false);
                break;

            case "skeleton":
                // Rapid-fire 10 arrows
                for (int i = 0; i < 10; i++) {
                    Arrow arrow = player.launchProjectile(Arrow.class);
                    arrow.setVelocity(arrow.getVelocity().multiply(1.5));
                }
                break;

            case "zombie":
                // Infect target
                Entity target = player.getTargetEntity(10);
                if (target instanceof LivingEntity) {
                    ((LivingEntity) target).addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 200, 1));
                }
                break;

            case "enderman":
                // Teleport to crosshair location
                Location targetLoc = player.getTargetBlock(null, 50).getLocation().add(0.5, 1, 0.5);
                player.teleport(targetLoc);
                break;

            case "witch":
                // Throw poison splash
                ThrownPotion potion = player.launchProjectile(ThrownPotion.class);
                potion.setItem(new ItemStack(Material.SPLASH_POTION));
                break;

            case "cow":
                // Milk all nearby entities
                player.getNearbyEntities(5, 5, 5).stream()
                    .filter(e -> e instanceof LivingEntity)
                    .forEach(e -> ((LivingEntity) e).removePotionEffects());
                break;

            case "sheep":
                // Rainbow wool explosion
                for (int i = 0; i < 20; i++) {
                    FallingBlock wool = player.getWorld().spawnFallingBlock(
                        player.getLocation(),
                        Material.WHITE_WOOL.createBlockData()
                    );
                    wool.setVelocity(new Vector(
                        Math.random() * 2 - 1,
                        Math.random() * 2,
                        Math.random() * 2 - 1
                    ));
                }
                break;

            case "pig":
                // Turbo boost
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 2));
                break;

            case "chicken":
                // Egg barrage
                for (int i = 0; i < 20; i++) {
                    Egg egg = player.launchProjectile(Egg.class);
                    egg.setVelocity(egg.getVelocity().multiply(1.5));
                }
                break;

            case "panda":
                // Belly flop
                player.setVelocity(new Vector(0, -1, 0));
                player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 20);
                break;

            case "dolphin":
                // Water torpedo dash
                player.setVelocity(player.getLocation().getDirection().multiply(2));
                player.getWorld().spawnParticle(Particle.WATER_SPLASH, player.getLocation(), 20);
                break;

            case "wither":
                abilityManager.useWitherHead(player, 1);
                break;

            case "ender_dragon":
                abilityManager.useDragonHead(player, 1);
                break;
        }

        setCooldown(player, cooldown);
        abilityManager.showCooldown(player, mobType, cooldown);
    }

    private void wearHead(Player player, String mobType) {
        wearingHeads.put(player.getUniqueId(), mobType);
        player.sendMessage(plugin.getConfig().getString("messages.head-worn")
                .replace("%mob%", mobType));

        // Play wear effects
        abilityManager.playVisualEffects(player.getLocation(), mobType);

        // Apply wear effects based on mob type
        switch (mobType.toLowerCase()) {
            case "creeper":
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 0));
                break;
            case "skeleton":
                player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 200, 0));
                break;
            case "zombie":
                player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 200, 0));
                break;
            case "enderman":
                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 200, 0));
                break;
            case "witch":
                player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 0));
                break;
            case "cow":
                player.addPotionEffect(new PotionEffect(PotionEffectType.SATURATION, 200, 0));
                break;
            case "sheep":
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, 200, 0));
                break;
            case "pig":
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 1));
                break;
            case "chicken":
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 200, 0));
                break;
            case "panda":
                player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 200, 0));
                break;
            case "dolphin":
                player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, 200, 0));
                break;
        }
    }

    private boolean isHead(ItemStack item) {
        return item.getType() == Material.PLAYER_HEAD;
    }

    private String getMobTypeFromHead(ItemStack item) {
        if (!(item.getItemMeta() instanceof SkullMeta)) return null;
        SkullMeta meta = (SkullMeta) item.getItemMeta();
        if (meta.getOwner() == null) return null;
        return meta.getOwner();
    }

    private boolean isOnCooldown(Player player, int cooldown) {
        if (!cooldowns.containsKey(player.getUniqueId())) return false;
        return System.currentTimeMillis() < cooldowns.get(player.getUniqueId());
    }

    private void setCooldown(Player player, int cooldown) {
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis() + (cooldown * 1000L));
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        if (event.getEntity() instanceof Skeleton) {
            Skeleton skeleton = (Skeleton) event.getEntity();
            if (skeleton.getScoreboardTags().contains("HS_Clone")) {
                cloneManager.handleCloneDeath(skeleton);
            }
        }
    }
} 