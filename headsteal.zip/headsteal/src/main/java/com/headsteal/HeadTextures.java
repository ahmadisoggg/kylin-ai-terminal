package com.headsteal;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.UUID;

public class HeadTextures {
    private static final String TEXTURE_URL = "http://textures.minecraft.net/texture/";

    public static ItemStack createHead(String texture) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        if (!(head.getItemMeta() instanceof SkullMeta)) return head;

        SkullMeta meta = (SkullMeta) head.getItemMeta();
        PlayerProfile profile = Bukkit.createPlayerProfile(UUID.randomUUID());
        PlayerTextures textures = profile.getTextures();
        
        try {
            textures.setSkin(new URL(TEXTURE_URL + texture));
            profile.setTextures(textures);
            meta.setOwnerProfile(profile);
            head.setItemMeta(meta);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        return head;
    }

    public static String getTextureForMob(String mobType) {
        // Return the appropriate texture ID for each mob type
        switch (mobType.toLowerCase()) {
            case "zombie":
                return "ZombieTextureID";
            case "skeleton":
                return "SkeletonTextureID";
            case "creeper":
                return "CreeperTextureID";
            // Add more mob textures as needed
            default:
                return null;
        }
    }
} 