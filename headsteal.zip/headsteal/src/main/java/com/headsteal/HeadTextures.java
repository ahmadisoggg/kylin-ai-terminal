package com.headsteal;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import org.bukkit.entity.EntityType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeadTextures {
    private final Map<EntityType, String> textures;

    public HeadTextures() {
        this.textures = new HashMap<>();
        initializeTextures();
    }

    private void initializeTextures() {
        // Vanilla Mobs
        textures.put(EntityType.CREEPER, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNGJhYzVkNjE1YzM5ZDIxZjhkN2I1YTRhYzQ3YjU5YzJhYzJmZGNiMWU1YTI0YTY3Y2U3Y2Q3Y2Y3YzQ3In19fQ==");
        textures.put(EntityType.ZOMBIE, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5In19fQ==");
        textures.put(EntityType.SKELETON, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5In19fQ==");
        textures.put(EntityType.SPIDER, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5In19fQ==");
        textures.put(EntityType.ENDERMAN, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5In19fQ==");
        textures.put(EntityType.WITHER_SKELETON, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5In19fQ==");
        textures.put(EntityType.BLAZE, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5In19fQ==");
        textures.put(EntityType.GHAST, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5In19fQ==");
        textures.put(EntityType.SLIME, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5In19fQ==");
        textures.put(EntityType.MAGMA_CUBE, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5In19fQ==");
        
        // 1.21 Specials
        textures.put(EntityType.BREEZE, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5YzM5In19fQ==");
    }

    public String getTexture(EntityType type) {
        return textures.get(type);
    }

    public GameProfile createProfile(String texture) {
        GameProfile profile = new GameProfile(UUID.randomUUID(), null);
        profile.getProperties().put("textures", new Property("textures", texture));
        return profile;
    }
} 