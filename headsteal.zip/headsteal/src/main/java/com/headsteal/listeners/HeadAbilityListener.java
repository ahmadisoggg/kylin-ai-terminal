package com.headsteal.listeners;

import com.headsteal.HeadSteal;
import com.headsteal.abilities.MobAbility;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeadAbilityListener implements Listener {
    private final HeadSteal plugin;
    private final Map<UUID, Long> cooldowns;

    public HeadAbilityListener() {
        this.plugin = HeadSteal.getInstance();
        this.cooldowns = new HashMap<>();
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();

        if (item == null || !(item.getItemMeta() instanceof SkullMeta)) {
            return;
        }

        // TODO: Get mob type from skull metadata
        String mobType = "CREEPER"; // Placeholder
        MobAbility ability = plugin.getAbility(mobType);

        if (ability == null) {
            return;
        }

        // Check cooldown
        if (isOnCooldown(player)) {
            long remainingTime = (cooldowns.get(player.getUniqueId()) - System.currentTimeMillis()) / 1000;
            player.sendMessage("§cThis ability is on cooldown for " + remainingTime + " seconds!");
            event.setCancelled(true);
            return;
        }

        // Check cost
        if (!hasEnoughResources(player, ability)) {
            player.sendMessage("§cYou don't have enough " + ability.getCostType().name().toLowerCase() + " to use this ability!");
            event.setCancelled(true);
            return;
        }

        // Apply cost
        applyCost(player, ability);

        // Execute ability
        if (event.getAction() == Action.LEFT_CLICK_AIR || event.getAction() == Action.LEFT_CLICK_BLOCK) {
            ability.onLeftClick(event, player);
        } else if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            ability.onRightClick(event, player);
        }

        // Set cooldown
        setCooldown(player, ability.getCooldown());
    }

    private boolean isOnCooldown(Player player) {
        if (!cooldowns.containsKey(player.getUniqueId())) {
            return false;
        }
        return System.currentTimeMillis() < cooldowns.get(player.getUniqueId());
    }

    private void setCooldown(Player player, int seconds) {
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis() + (seconds * 1000L));
    }

    private boolean hasEnoughResources(Player player, MobAbility ability) {
        switch (ability.getCostType()) {
            case HEALTH:
                return player.getHealth() > ability.getCost();
            case HUNGER:
                return player.getFoodLevel() > ability.getCost();
            case XP:
                return player.getLevel() >= ability.getCost();
            default:
                return false;
        }
    }

    private void applyCost(Player player, MobAbility ability) {
        switch (ability.getCostType()) {
            case HEALTH:
                player.damage(ability.getCost());
                break;
            case HUNGER:
                player.setFoodLevel(player.getFoodLevel() - ability.getCost());
                break;
            case XP:
                player.setLevel(player.getLevel() - ability.getCost());
                break;
        }
    }
} 