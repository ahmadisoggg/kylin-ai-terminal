package com.headsteal.abilities;

import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

public interface MobAbility {
    /**
     * Called when a player left-clicks with the mob head
     * @param event The interaction event
     * @param player The player using the ability
     */
    void onLeftClick(PlayerInteractEvent event, Player player);

    /**
     * Called when a player right-clicks with the mob head
     * @param event The interaction event
     * @param player The player using the ability
     */
    void onRightClick(PlayerInteractEvent event, Player player);

    /**
     * Get the cooldown time in seconds for this ability
     * @return Cooldown time in seconds
     */
    int getCooldown();

    /**
     * Get the cost of using this ability (health, hunger, or XP)
     * @return Cost value
     */
    int getCost();

    /**
     * Get the type of cost (HEALTH, HUNGER, XP)
     * @return Cost type
     */
    CostType getCostType();

    enum CostType {
        HEALTH,
        HUNGER,
        XP
    }
} 