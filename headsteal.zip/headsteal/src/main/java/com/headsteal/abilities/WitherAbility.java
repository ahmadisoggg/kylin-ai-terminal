package com.headsteal.abilities;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.WitherSkull;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.util.Vector;

public class WitherAbility implements MobAbility {
    private static final int COOLDOWN = 120; // 120 seconds cooldown
    private static final int COST = 3; // 3 hearts cost

    @Override
    public void onLeftClick(PlayerInteractEvent event, Player player) {
        // Homing wither skull
        Location loc = player.getLocation();
        WitherSkull skull = (WitherSkull) player.getWorld().spawnEntity(loc, EntityType.WITHER_SKULL);
        
        // Set skull properties
        skull.setCharged(true);
        skull.setDirection(player.getLocation().getDirection());
        
        // Make it homing
        player.getWorld().playSound(loc, Sound.ENTITY_WITHER_SHOOT, 1.0f, 1.0f);
    }

    @Override
    public void onRightClick(PlayerInteractEvent event, Player player) {
        // Summon 3 wither skeletons
        Location loc = player.getLocation();
        for (int i = 0; i < 3; i++) {
            Location spawnLoc = loc.clone().add(
                Math.random() * 4 - 2,
                0,
                Math.random() * 4 - 2
            );
            player.getWorld().spawnEntity(spawnLoc, EntityType.WITHER_SKELETON);
        }
        
        player.getWorld().playSound(loc, Sound.ENTITY_WITHER_SPAWN, 1.0f, 1.0f);
    }

    @Override
    public int getCooldown() {
        return COOLDOWN;
    }

    @Override
    public int getCost() {
        return COST;
    }

    @Override
    public CostType getCostType() {
        return CostType.HEALTH;
    }
} 