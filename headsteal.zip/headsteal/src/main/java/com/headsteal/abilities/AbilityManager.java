package com.headsteal.abilities;

import com.headsteal.HeadSteal;
import org.bukkit.*;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

public class AbilityManager {
    private final HeadSteal plugin;
    private final Map<UUID, Map<String, Integer>> playerPhases;
    private final Map<UUID, BossBar> playerBossBars;

    public AbilityManager(HeadSteal plugin) {
        this.plugin = plugin;
        this.playerPhases = new HashMap<>();
        this.playerBossBars = new HashMap<>();
    }

    public boolean canUseAbility(Player player, String mobType, int phase) {
        if (!hasPhase(player, mobType, phase)) {
            player.sendMessage(plugin.getConfig().getString("messages.phase-locked")
                    .replace("%phase%", getPhaseName(mobType, phase))
                    .replace("%mob%", mobType));
            return false;
        }

        if (!hasRequiredCost(player, mobType, phase)) {
            return false;
        }

        return true;
    }

    public boolean hasPhase(Player player, String mobType, int phase) {
        Map<String, Integer> phases = playerPhases.getOrDefault(player.getUniqueId(), new HashMap<>());
        return phases.getOrDefault(mobType, 0) >= phase;
    }

    public void unlockPhase(Player player, String mobType, int phase) {
        Map<String, Integer> phases = playerPhases.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>());
        phases.put(mobType, Math.max(phases.getOrDefault(mobType, 0), phase));
        
        player.sendMessage(plugin.getConfig().getString("messages.phase-unlocked")
                .replace("%phase%", getPhaseName(mobType, phase))
                .replace("%mob%", mobType));
    }

    private String getPhaseName(String mobType, int phase) {
        return plugin.getConfig().getString("abilities.phases." + mobType + ".phase" + phase + ".name", "Phase " + phase);
    }

    private boolean hasRequiredCost(Player player, String mobType, int phase) {
        int healthCost = plugin.getConfig().getInt("abilities.costs.health." + mobType, 0);
        int xpCost = plugin.getConfig().getInt("abilities.costs.xp." + mobType, 0);
        int hungerCost = plugin.getConfig().getInt("abilities.costs.hunger." + mobType, 0);

        if (healthCost > 0 && player.getHealth() <= healthCost) {
            player.sendMessage(plugin.getConfig().getString("messages.not-enough-health"));
            return false;
        }

        if (xpCost > 0 && player.getLevel() < xpCost) {
            player.sendMessage(plugin.getConfig().getString("messages.not-enough-xp"));
            return false;
        }

        if (hungerCost > 0 && player.getFoodLevel() < hungerCost) {
            player.sendMessage(plugin.getConfig().getString("messages.not-enough-hunger"));
            return false;
        }

        return true;
    }

    public void applyCost(Player player, String mobType, int phase) {
        int healthCost = plugin.getConfig().getInt("abilities.costs.health." + mobType, 0);
        int xpCost = plugin.getConfig().getInt("abilities.costs.xp." + mobType, 0);
        int hungerCost = plugin.getConfig().getInt("abilities.costs.hunger." + mobType, 0);

        if (healthCost > 0) {
            player.damage(healthCost);
        }

        if (xpCost > 0) {
            player.setLevel(player.getLevel() - xpCost);
        }

        if (hungerCost > 0) {
            player.setFoodLevel(player.getFoodLevel() - hungerCost);
        }
    }

    public void showCooldown(Player player, String mobType, int cooldown) {
        if (!plugin.getConfig().getBoolean("visual-feedback.bossbar.enabled", true)) {
            return;
        }

        BossBar bossBar = playerBossBars.computeIfAbsent(player.getUniqueId(), 
            k -> Bukkit.createBossBar(
                ChatColor.translateAlternateColorCodes('&', 
                    "&e" + mobType + " Ability &7- &f" + cooldown + "s"),
                BarColor.YELLOW,
                BarStyle.SOLID
            )
        );

        bossBar.setTitle(ChatColor.translateAlternateColorCodes('&', 
            "&e" + mobType + " Ability &7- &f" + cooldown + "s"));
        bossBar.setProgress(1.0);
        bossBar.addPlayer(player);

        new BukkitRunnable() {
            double time = cooldown;
            @Override
            public void run() {
                time -= 0.1;
                if (time <= 0) {
                    bossBar.removePlayer(player);
                    cancel();
                    return;
                }
                bossBar.setProgress(time / cooldown);
                bossBar.setTitle(ChatColor.translateAlternateColorCodes('&', 
                    "&e" + mobType + " Ability &7- &f" + String.format("%.1f", time) + "s"));
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    public void playVisualEffects(Location location, String mobType) {
        if (plugin.getConfig().getBoolean("visual-feedback.particles.enabled", true)) {
            int count = plugin.getConfig().getInt("visual-feedback.particles.count", 20);
            location.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, location, count, 0.5, 0.5, 0.5, 0.1);
        }

        if (plugin.getConfig().getBoolean("visual-feedback.sounds.enabled", true)) {
            float volume = (float) plugin.getConfig().getDouble("visual-feedback.sounds.volume", 1.0);
            location.getWorld().playSound(location, Sound.BLOCK_NOTE_BLOCK_PLING, volume, 1.2f);
        }
    }

    // Special ability implementations
    public void useDragonHead(Player player, int phase) {
        if (phase == 1) {
            // Phase 1: Dragon breath
            Location loc = player.getLocation();
            for (int i = 0; i < 360; i += 10) {
                double angle = Math.toRadians(i);
                double x = Math.cos(angle) * 2;
                double z = Math.sin(angle) * 2;
                loc.add(x, 0, z);
                loc.getWorld().spawnParticle(Particle.DRAGON_BREATH, loc, 1, 0, 0, 0, 0);
                loc.subtract(x, 0, z);
            }
        } else if (phase == 2) {
            // Phase 2: Endermite swarm
            for (int i = 0; i < 8; i++) {
                Endermite endermite = player.getWorld().spawn(player.getLocation(), Endermite.class);
                endermite.setTarget(player.getTargetEntity(50));
            }
        }
    }

    public void useWitherHead(Player player, int phase) {
        if (phase == 1) {
            // Phase 1: Single wither skull
            WitherSkull skull = player.getWorld().spawn(player.getEyeLocation(), WitherSkull.class);
            skull.setDirection(player.getLocation().getDirection());
            skull.setShooter(player);
        } else if (phase == 2) {
            // Phase 2: Skull barrage
            for (int i = 0; i < 12; i++) {
                WitherSkull skull = player.getWorld().spawn(player.getEyeLocation(), WitherSkull.class);
                Vector direction = player.getLocation().getDirection();
                direction.rotateAroundY(Math.toRadians(i * 30));
                skull.setDirection(direction);
                skull.setShooter(player);
            }
        }
    }

    private void useEndermiteHead(Player player, int phase) {
        if (phase == 1) {
            Endermite endermite = player.getWorld().spawn(player.getLocation(), Endermite.class);
            Entity target = player.getTargetEntity(50);
            if (target instanceof LivingEntity) {
                endermite.setTarget((LivingEntity) target);
            }
        }
    }
} 