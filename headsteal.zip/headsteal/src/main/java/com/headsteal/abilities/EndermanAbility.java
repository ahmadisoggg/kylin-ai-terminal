package com.headsteal.abilities;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class EndermanAbility implements MobAbility {
    private static final int COOLDOWN = 15; // 15 seconds cooldown
    private static final int COST = 2; // 2 hearts cost

    @Override
    public void onLeftClick(PlayerInteractEvent event, Player player) {
        // Teleport swap with target
        Entity target = player.getTargetEntity(50);
        if (target != null && target instanceof Player) {
            Player targetPlayer = (Player) target;
            Location playerLoc = player.getLocation();
            Location targetLoc = targetPlayer.getLocation();
            
            player.teleport(targetLoc);
            targetPlayer.teleport(playerLoc);
        }
    }

    @Override
    public void onRightClick(PlayerInteractEvent event, Player player) {
        // Steal held item
        Entity target = player.getTargetEntity(50);
        if (target != null && target instanceof Player) {
            Player targetPlayer = (Player) target;
            ItemStack heldItem = targetPlayer.getInventory().getItemInMainHand();
            
            if (heldItem != null && heldItem.getType() != Material.AIR) {
                player.getInventory().addItem(heldItem);
                targetPlayer.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
            }
        }
    }

    @Override
    public int getCooldown() {
        return COOLDOWN;
    }

    @Override
    public int getCost() {
        return COST;
    }

    @Override
    public CostType getCostType() {
        return CostType.HEALTH;
    }
} 