package com.headsteal.abilities;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.util.Vector;

public class CreeperAbility implements MobAbility {
    private static final int COOLDOWN = 30; // 30 seconds cooldown
    private static final int COST = 2; // 2 hearts cost
    private static final double EXPLOSION_RADIUS = 3.0;

    @Override
    public void onLeftClick(PlayerInteractEvent event, Player player) {
        // Suicide explosion
        Location loc = player.getLocation();
        player.getWorld().createExplosion(loc, (float) EXPLOSION_RADIUS, false, true, player);
        player.damage(20.0); // Kill the player
    }

    @Override
    public void onRightClick(PlayerInteractEvent event, Player player) {
        // Plant TNT landmine
        Location loc = event.getClickedBlock().getLocation().add(0.5, 1, 0.5);
        TNTPrimed tnt = player.getWorld().spawn(loc, TNTPrimed.class);
        tnt.setFuseTicks(Integer.MAX_VALUE); // Won't explode until triggered
        tnt.setYield(4.0f);
        
        // Make it invisible and invulnerable
        tnt.setInvisible(true);
        tnt.setInvulnerable(true);
        
        // Store the TNT in a custom data structure for later detection
        // This would be handled by a separate TNTManager class
    }

    @Override
    public int getCooldown() {
        return COOLDOWN;
    }

    @Override
    public int getCost() {
        return COST;
    }

    @Override
    public CostType getCostType() {
        return CostType.HEALTH;
    }
} 