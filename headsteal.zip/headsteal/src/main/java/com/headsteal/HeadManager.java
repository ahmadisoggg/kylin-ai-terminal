package com.headsteal;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HeadManager {
    private final HeadSteal plugin;
    private final Random random;
    private final ExecutorService textureLoader;
    private final HeadTextures textures;
    private final Map<UUID, Map<String, Integer>> playerStats;
    private final Map<UUID, Integer> totalHeads;

    public HeadManager(HeadSteal plugin) {
        this.plugin = plugin;
        this.random = new Random();
        this.textureLoader = Executors.newVirtualThreadPerTaskExecutor();
        this.textures = new HeadTextures();
        this.playerStats = new HashMap<>();
        this.totalHeads = new HashMap<>();
    }

    public void stealHead(Entity victim, Player killer) {
        if (!killer.hasPermission("headsteal.collect")) return;

        CompletableFuture.supplyAsync(() -> create3DHead(victim), textureLoader)
            .thenAccept(head -> {
                if (head != null) {
                    head = addLore(head, killer);
                    killer.getInventory().addItem(head);
                    playPlopEffect(victim.getLocation());
                    
                    String message = plugin.getConfig().getString("messages.head-collected", "&aYou collected a %mob% head!")
                        .replace("%mob%", victim.getType().name().toLowerCase());
                    killer.sendMessage(message);
                }
            });
    }

    public void triggerHeadRain(Location loc, EntityType type, int count) {
        for (int i = 0; i < count; i++) {
            CompletableFuture.supplyAsync(() -> create3DHead(type), textureLoader)
                .thenAccept(head -> {
                    if (head != null) {
                        Item item = loc.getWorld().dropItem(loc, head);
                        item.setVelocity(randomArc());
                    }
                });
        }
    }

    private ItemStack create3DHead(Entity entity) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        
        if (meta != null) {
            String texture = textures.getTexture(entity.getType());
            if (texture != null) {
                meta.setOwnerProfile(textures.createProfile(texture));
                head.setItemMeta(meta);
                return head;
            }
        }
        return null;
    }

    private ItemStack addLore(ItemStack head, Player killer) {
        // Add lore implementation
        return head;
    }

    private void playPlopEffect(Location location) {
        String soundName = plugin.getConfig().getString("effects.sound", "BLOCK_NOTE_BLOCK_PLING");
        float volume = (float) plugin.getConfig().getDouble("effects.volume", 1.2);
        
        try {
            Sound sound = Sound.valueOf(soundName);
            location.getWorld().playSound(location, sound, volume, 1.0f);
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("Invalid sound effect configured: " + soundName);
        }
    }

    private Vector randomArc() {
        double x = random.nextDouble() * 2 - 1;
        double y = random.nextDouble() * 0.5;
        double z = random.nextDouble() * 2 - 1;
        return new Vector(x, y, z).normalize().multiply(0.5);
    }

    public double getDropChance(EntityType type, int lootingLevel) {
        String configPath = "drops.special-mobs." + type.name().toLowerCase();
        double baseChance = plugin.getConfig().getDouble(configPath, 
            plugin.getConfig().getDouble("drops.default-chance", 7.5));
        
        double multiplier = plugin.getConfig().getDouble("drops.looting-multiplier", 1.15);
        return baseChance * Math.pow(multiplier, lootingLevel);
    }

    public void addHead(Player player, String mobType) {
        UUID playerId = player.getUniqueId();
        
        // Update player stats
        Map<String, Integer> stats = playerStats.computeIfAbsent(playerId, k -> new HashMap<>());
        stats.put(mobType, stats.getOrDefault(mobType, 0) + 1);
        
        // Update total heads
        totalHeads.put(playerId, totalHeads.getOrDefault(playerId, 0) + 1);
        
        // Save stats to config
        saveStats(player);
    }

    public Map<String, Integer> getPlayerStats(Player player) {
        return playerStats.getOrDefault(player.getUniqueId(), new HashMap<>());
    }

    public int getTotalHeads(Player player) {
        return totalHeads.getOrDefault(player.getUniqueId(), 0);
    }

    public void saveStats(Player player) {
        String path = "stats." + player.getUniqueId();
        plugin.getConfig().set(path + ".total", getTotalHeads(player));
        
        Map<String, Integer> stats = getPlayerStats(player);
        for (Map.Entry<String, Integer> entry : stats.entrySet()) {
            plugin.getConfig().set(path + ".mobs." + entry.getKey(), entry.getValue());
        }
        
        plugin.saveConfig();
    }

    public void loadStats(Player player) {
        String path = "stats." + player.getUniqueId();
        if (!plugin.getConfig().contains(path)) return;
        
        totalHeads.put(player.getUniqueId(), plugin.getConfig().getInt(path + ".total", 0));
        
        if (plugin.getConfig().contains(path + ".mobs")) {
            Map<String, Integer> stats = new HashMap<>();
            for (String mob : plugin.getConfig().getConfigurationSection(path + ".mobs").getKeys(false)) {
                stats.put(mob, plugin.getConfig().getInt(path + ".mobs." + mob));
            }
            playerStats.put(player.getUniqueId(), stats);
        }
    }

    public ItemStack createHead(String mobType) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        if (meta != null) {
            meta.setOwner(mobType);
            head.setItemMeta(meta);
        }
        return head;
    }

    public void triggerHeadRain(Location location, String mobType, int amount) {
        for (int i = 0; i < amount; i++) {
            location.getWorld().dropItemNaturally(location, createHead(mobType));
        }
    }
} 