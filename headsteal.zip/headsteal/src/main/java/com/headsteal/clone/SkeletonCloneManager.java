package com.headsteal.clone;

import com.headsteal.HeadSteal;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SkeletonCloneManager {
    private final HeadSteal plugin;
    private final Map<UUID, Long> cloneCooldowns;
    private final Map<UUID, Integer> activeClones;

    public SkeletonCloneManager(HeadSteal plugin) {
        this.plugin = plugin;
        this.cloneCooldowns = new HashMap<>();
        this.activeClones = new HashMap<>();
    }

    public boolean canCreateClone(Player player) {
        if (!player.hasPermission("headsteal.clone")) {
            return false;
        }

        // Check cooldown
        Long cooldownEnd = cloneCooldowns.get(player.getUniqueId());
        if (cooldownEnd != null && System.currentTimeMillis() < cooldownEnd) {
            long remaining = (cooldownEnd - System.currentTimeMillis()) / 1000;
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.clone-cooldown")
                    .replace("%time%", String.valueOf(remaining))));
            return false;
        }

        // Check max clones
        int currentClones = activeClones.getOrDefault(player.getUniqueId(), 0);
        int maxClones = plugin.getConfig().getInt("skeleton-clone.max-clones", 3);
        if (currentClones >= maxClones) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.max-clones")));
            return false;
        }

        return true;
    }

    public void createClone(Player player) {
        if (!canCreateClone(player)) return;

        // Create clone
        Skeleton clone = (Skeleton) player.getWorld().spawnEntity(
            player.getLocation(),
            org.bukkit.entity.EntityType.SKELETON
        );

        // Dress clone
        dressClone(clone, player);

        // Set AI behavior
        if (plugin.getConfig().getBoolean("skeleton-clone.attack-owner", true)) {
            clone.setTarget(player);
        }

        // Add glowing effect
        if (plugin.getConfig().getBoolean("skeleton-clone.glow-effect", true)) {
            new BukkitRunnable() {
                @Override
                public void run() {
                    clone.addPotionEffect(new PotionEffect(
                        PotionEffectType.GLOWING, 100, 0
                    ));
                }
            }.runTaskLater(plugin, 20L);
        }

        // Update clone count
        activeClones.merge(player.getUniqueId(), 1, Integer::sum);

        // Apply cooldown
        int cooldown = plugin.getConfig().getInt("skeleton-clone.cooldown", 60);
        cloneCooldowns.put(player.getUniqueId(), System.currentTimeMillis() + (cooldown * 1000L));

        // Send message
        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
            plugin.getConfig().getString("messages.clone-created")));

        // Schedule clone removal
        int duration = plugin.getConfig().getInt("skeleton-clone.duration", 300);
        new BukkitRunnable() {
            @Override
            public void run() {
                if (clone.isValid()) {
                    clone.remove();
                    activeClones.merge(player.getUniqueId(), -1, Integer::sum);
                }
            }
        }.runTaskLater(plugin, duration * 20L);
    }

    private void dressClone(Skeleton clone, Player original) {
        if (plugin.getConfig().getBoolean("skeleton-clone.equipment-copy", true)) {
            // Copy armor visually
            ItemStack[] armor = original.getInventory().getArmorContents();
            for (int i = 0; i < armor.length; i++) {
                if (armor[i] != null) {
                    ItemStack copy = armor[i].clone();
                    copy.setDurability((short) 0); // Make unbreakable
                    clone.getEquipment().setArmorContents(new ItemStack[]{copy, null, null, null});
                }
            }
        }

        // Set name
        String nameFormat = plugin.getConfig().getString("skeleton-clone.name-format", "&7Clone of &f{player}");
        String name = ChatColor.translateAlternateColorCodes('&',
            nameFormat.replace("{player}", original.getName()));
        clone.setCustomName(name);
        clone.setCustomNameVisible(true);
    }

    public void removeAllClones(Player player) {
        player.getWorld().getEntities().stream()
            .filter(e -> e instanceof Skeleton)
            .filter(e -> e.getCustomName() != null && e.getCustomName().contains("Clone of " + player.getName()))
            .forEach(e -> {
                e.remove();
                activeClones.merge(player.getUniqueId(), -1, Integer::sum);
            });

        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
            plugin.getConfig().getString("messages.clone-removed")));
    }

    public int getActiveClones(Player player) {
        return activeClones.getOrDefault(player.getUniqueId(), 0);
    }

    public void handleCloneDeath(Skeleton clone) {
        if (clone.getCustomName() != null && clone.getCustomName().contains("Clone of")) {
            // Clear drops
            clone.getEquipment().clear();
            
            // Add custom drops
            if (plugin.getConfig().getBoolean("skeleton-clone.drop-bones", true)) {
                int bones = plugin.getConfig().getInt("skeleton-clone.drop-bones", 3);
                clone.getWorld().dropItemNaturally(clone.getLocation(), new ItemStack(Material.BONE, bones));
            }
            
            if (plugin.getConfig().getBoolean("skeleton-clone.drop-skull", true)) {
                clone.getWorld().dropItemNaturally(clone.getLocation(), new ItemStack(Material.SKELETON_SKULL));
            }
        }
    }
} 