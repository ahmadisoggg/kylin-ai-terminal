package com.headsteal.commands;

import com.headsteal.HeadSteal;
import com.headsteal.abilities.MobAbility;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;

public class HeadAbilityCommand implements CommandExecutor {
    private final HeadSteal plugin;

    public HeadAbilityCommand() {
        this.plugin = HeadSteal.getInstance();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length != 1) {
            sender.sendMessage("§cUsage: /headability <mob>");
            return true;
        }

        String mobType = args[0].toUpperCase();
        try {
            EntityType.valueOf(mobType);
        } catch (IllegalArgumentException e) {
            sender.sendMessage("§cInvalid mob type! Use a valid Minecraft mob name.");
            return true;
        }

        MobAbility ability = plugin.getAbility(mobType);
        if (ability == null) {
            sender.sendMessage("§cThis mob doesn't have any abilities!");
            return true;
        }

        // Format ability information
        StringBuilder info = new StringBuilder();
        info.append("§e=== ").append(mobType).append(" Abilities ===\n");
        info.append("§7Left-Click: §fOffensive ability\n");
        info.append("§7Right-Click: §fUtility ability\n");
        info.append("§7Cooldown: §f").append(ability.getCooldown()).append(" seconds\n");
        info.append("§7Cost: §f").append(ability.getCost()).append(" ").append(ability.getCostType().name().toLowerCase());

        sender.sendMessage(info.toString());
        return true;
    }
} 