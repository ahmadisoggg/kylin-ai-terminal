package com.headsteal.commands;

import com.headsteal.HeadSteal;
import com.headsteal.abilities.AbilityManager;
import com.headsteal.clone.SkeletonCloneManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class HeadStealCmd implements CommandExecutor, TabCompleter {
    private final HeadSteal plugin;
    private final SkeletonCloneManager cloneManager;
    private final AbilityManager abilityManager;

    public HeadStealCmd(HeadSteal plugin) {
        this.plugin = plugin;
        this.cloneManager = new SkeletonCloneManager(plugin);
        this.abilityManager = new AbilityManager(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cUsage: /headsteal <give|stats|ability|cooldown|repair|clone|upgrade|list>"));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "give":
                return handleGiveCommand(sender, args);
            case "stats":
                return handleStatsCommand(sender);
            case "ability":
                return handleAbilityCommand(sender, args);
            case "cooldown":
                return handleCooldownCommand(sender);
            case "repair":
                return handleRepairCommand(sender);
            case "clone":
                return handleCloneCommand(sender, args);
            case "upgrade":
                return handleUpgradeCommand(sender, args);
            case "list":
                return handleListCommand(sender);
            default:
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    plugin.getConfig().getString("messages.prefix") + "&cUnknown subcommand!"));
                return true;
        }
    }

    private boolean handleGiveCommand(CommandSender sender, String[] args) {
        if (!sender.hasPermission("headsteal.give")) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.no-permission")));
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cUsage: /headsteal give <player> <mob> [amount]"));
            return true;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.invalid-player")));
            return true;
        }

        String mobType = args[2].toLowerCase();
        int amount = args.length > 3 ? Integer.parseInt(args[3]) : 1;

        ItemStack head = createMobHead(mobType, amount);
        if (head == null) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.invalid-mob")));
            return true;
        }

        target.getInventory().addItem(head);
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
            plugin.getConfig().getString("messages.head-given")
                .replace("%mob%", mobType)));
        return true;
    }

    private boolean handleStatsCommand(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cThis command can only be used by players!"));
            return true;
        }

        Player player = (Player) sender;
        Map<String, Integer> stats = plugin.getHeadManager().getPlayerStats(player);
        int total = plugin.getHeadManager().getTotalHeads(player);

        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&8&m--------------------------------"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&c&lHeadSteal &7- &f" + player.getName() + "'s Stats"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&8&m--------------------------------"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7Total Heads Collected: &f" + total));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&8&m--------------------------------"));
        
        if (!stats.isEmpty()) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                "&c&lHead Collection:"));
            stats.entrySet().stream()
                .sorted((a, b) -> b.getValue().compareTo(a.getValue()))
                .forEach(entry -> sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    "&7• &f" + entry.getKey() + " &7- &e" + entry.getValue())));
        } else {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                "&7No heads collected yet!"));
        }
        
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&8&m--------------------------------"));
        return true;
    }

    private boolean handleAbilityCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cThis command can only be used by players!"));
            return true;
        }

        Player player = (Player) sender;
        if (args.length < 2) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cUsage: /headsteal ability <mob>"));
            return true;
        }

        String mobType = args[1].toLowerCase();
        int cooldown = plugin.getConfig().getInt("abilities.cooldowns." + mobType, 30);
        int cost = plugin.getConfig().getInt("abilities.costs.hunger." + mobType, 1);

        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
            plugin.getConfig().getString("messages.prefix") + "&a" + mobType + " Head Ability:"));
        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
            "&7• Cooldown: &f" + cooldown + "s"));
        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
            "&7• Cost: &f" + cost + " hunger"));
        return true;
    }

    private boolean handleCooldownCommand(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cThis command can only be used by players!"));
            return true;
        }

        Player player = (Player) sender;
        ItemStack helmet = player.getInventory().getHelmet();
        if (helmet == null || helmet.getType() != Material.PLAYER_HEAD) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cYou must be wearing a mob head!"));
            return true;
        }

        // TODO: Implement cooldown display
        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
            plugin.getConfig().getString("messages.prefix") + "&aCooldown display coming soon!"));
        return true;
    }

    private boolean handleRepairCommand(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cThis command can only be used by players!"));
            return true;
        }

        Player player = (Player) sender;
        ItemStack helmet = player.getInventory().getHelmet();
        if (helmet == null || helmet.getType() != Material.PLAYER_HEAD) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cYou must be wearing a mob head!"));
            return true;
        }

        // TODO: Implement head repair
        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
            plugin.getConfig().getString("messages.prefix") + "&aHead repair coming soon!"));
        return true;
    }

    private boolean handleCloneCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cThis command can only be used by players!"));
            return true;
        }

        Player player = (Player) sender;
        if (args.length < 2) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cUsage: /headsteal clone <list|recall>"));
            return true;
        }

        switch (args[1].toLowerCase()) {
            case "list":
                int activeClones = cloneManager.getActiveClones(player);
                player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    plugin.getConfig().getString("messages.prefix") + "&aActive clones: &f" + activeClones));
                break;
            case "recall":
                cloneManager.removeAllClones(player);
                break;
            default:
                player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    plugin.getConfig().getString("messages.prefix") + "&cUnknown clone subcommand!"));
                break;
        }
        return true;
    }

    private boolean handleUpgradeCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cThis command can only be used by players!"));
            return true;
        }

        Player player = (Player) sender;
        if (args.length < 2) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix") + "&cUsage: /headsteal upgrade <mob>"));
            return true;
        }

        String mobType = args[1].toLowerCase();
        if (abilityManager.hasPhase(player, mobType, 1)) {
            abilityManager.unlockPhase(player, mobType, 2);
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.ability-upgraded")
                    .replace("%mob%", mobType)));
        } else {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.phase-locked")
                    .replace("%phase%", "Phase 2")
                    .replace("%mob%", mobType)));
        }
        return true;
    }

    private boolean handleListCommand(CommandSender sender) {
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&8&m--------------------------------"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&c&lHeadSteal &7- &fAvailable Abilities"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&8&m--------------------------------"));
        
        // Hostile Mobs
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&c&lHostile Mobs:"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fCreeper &7- &eExplosion &7(&fLeft&7) &7- &eCharged &7(&fRight&7)"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fSkeleton &7- &eRapid Fire &7(&fLeft&7) &7- &eClone &7(&fRight&7)"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fZombie &7- &eInfect &7(&fLeft&7) &7- &eMinions &7(&fRight&7)"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fEnderman &7- &eTeleport &7(&fLeft&7) &7- &eSteal &7(&fRight&7)"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fWitch &7- &ePoison &7(&fLeft&7) &7- &eBrew &7(&fRight&7)"));
        
        // Passive Mobs
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&a&lPassive Mobs:"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fCow &7- &eMilk &7(&fLeft&7) &7- &eRain &7(&fRight&7)"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fSheep &7- &eWool &7(&fLeft&7) &7- &eColor &7(&fRight&7)"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fPig &7- &eBoost &7(&fLeft&7) &7- &eLightning &7(&fRight&7)"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fChicken &7- &eEggs &7(&fLeft&7) &7- &eFlight &7(&fRight&7)"));
        
        // Neutral Mobs
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&e&lNeutral Mobs:"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fPanda &7- &eBelly Flop &7(&fLeft&7) &7- &eBamboo &7(&fRight&7)"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fDolphin &7- &eDash &7(&fLeft&7) &7- &eOxygen &7(&fRight&7)"));
        
        // Boss Mobs
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&4&lBoss Mobs:"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fWither &7- &eSkull Barrage &7(&fLeft&7) &7- &eWither Effect &7(&fRight&7)"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7• &fEnder Dragon &7- &eBreath Wave &7(&fLeft&7) &7- &eEndermite Swarm &7(&fRight&7)"));
        
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&8&m--------------------------------"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&7Use &f/headsteal ability <mob> &7for details"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', 
            "&8&m--------------------------------"));
        return true;
    }

    private ItemStack createMobHead(String mobType, int amount) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD, amount);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        if (meta == null) return null;

        meta.setOwner(mobType);
        head.setItemMeta(meta);
        return head;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList("give", "stats", "ability", "cooldown", "repair", "clone", "upgrade", "list");
        } else if (args.length == 2) {
            switch (args[0].toLowerCase()) {
                case "give":
                    return Bukkit.getOnlinePlayers().stream()
                        .map(Player::getName)
                        .collect(Collectors.toList());
                case "ability":
                case "upgrade":
                    return Arrays.asList("creeper", "skeleton", "zombie", "enderman", "witch", "cow", "sheep", "pig", "chicken", "panda", "dolphin", "wither", "ender_dragon");
                case "clone":
                    return Arrays.asList("list", "recall");
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return Arrays.asList("1", "2", "3", "4", "5", "10", "16", "32", "64");
        }
        return new ArrayList<>();
    }
} 