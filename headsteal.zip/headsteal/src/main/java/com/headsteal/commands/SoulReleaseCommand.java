package com.headsteal.commands;

import com.headsteal.HeadSteal;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SoulReleaseCommand implements CommandExecutor {
    private final HeadSteal plugin;

    public SoulReleaseCommand() {
        this.plugin = HeadSteal.getInstance();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cThis command can only be used by players!");
            return true;
        }

        Player player = (Player) sender;

        // Check if player has enough XP levels
        if (player.getLevel() < 5) {
            player.sendMessage("§cYou need 5 XP levels to release your soul!");
            return true;
        }

        // TODO: Implement soul release logic
        // This would involve:
        // 1. Checking if the player is actually trapped
        // 2. Removing the soul binding
        // 3. Taking 5 XP levels
        // 4. Teleporting player back to their original location
        // 5. Sending success message

        player.setLevel(player.getLevel() - 5);
        player.sendMessage("§aYou have successfully released your soul!");
        return true;
    }
} 