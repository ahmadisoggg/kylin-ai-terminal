package com.headsteal.commands;

import com.headsteal.HeadSteal;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

public class SoulBindCommand implements CommandExecutor {
    private final HeadSteal plugin;

    public SoulBindCommand() {
        this.plugin = HeadSteal.getInstance();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cThis command can only be used by players!");
            return true;
        }

        if (args.length != 1) {
            sender.sendMessage("§cUsage: /soulbind <player>");
            return true;
        }

        Player player = (Player) sender;
        Player target = Bukkit.getPlayer(args[0]);

        if (target == null) {
            sender.sendMessage("§cPlayer not found!");
            return true;
        }

        ItemStack item = player.getInventory().getItemInMainHand();
        if (!(item.getItemMeta() instanceof SkullMeta)) {
            sender.sendMessage("§cYou must be holding a mob head!");
            return true;
        }

        // TODO: Implement soul binding logic
        // This would involve:
        // 1. Checking if the head is a valid mob head
        // 2. Creating a custom NBT tag to store the soul
        // 3. Updating the item metadata
        // 4. Sending success message

        sender.sendMessage("§aSuccessfully soulbound " + target.getName() + "'s soul to the head!");
        return true;
    }
} 