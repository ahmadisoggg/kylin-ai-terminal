package com.headsteal.managers;

import com.headsteal.HeadSteal;
import com.headsteal.utils.HeadTextures;
import org.bukkit.*;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HeadManager {
    private final HeadSteal plugin;
    private final HeadTextures textures;
    private final Map<UUID, String> soulboundHeads;
    private final ExecutorService textureLoader;
    private final Map<EntityType, Double> dropChances;

    public HeadManager(HeadSteal plugin) {
        this.plugin = plugin;
        this.textures = new HeadTextures();
        this.soulboundHeads = new HashMap<>();
        this.textureLoader = Executors.newFixedThreadPool(2);
        this.dropChances = new HashMap<>();
        initializeDropChances();
    }

    private void initializeDropChances() {
        // Boss mobs
        dropChances.put(EntityType.WITHER, 100.0);
        dropChances.put(EntityType.ENDER_DRAGON, 100.0);
        dropChances.put(EntityType.WARDEN, 100.0);

        // Hostile mobs
        dropChances.put(EntityType.ZOMBIE, 5.0);
        dropChances.put(EntityType.SKELETON, 5.0);
        dropChances.put(EntityType.CREEPER, 5.0);
        dropChances.put(EntityType.SPIDER, 5.0);
        dropChances.put(EntityType.ENDERMAN, 5.0);
        dropChances.put(EntityType.WITCH, 5.0);
        dropChances.put(EntityType.SLIME, 5.0);
        dropChances.put(EntityType.PHANTOM, 5.0);
        dropChances.put(EntityType.DROWNED, 5.0);
        dropChances.put(EntityType.HUSK, 5.0);
        dropChances.put(EntityType.STRAY, 5.0);
        dropChances.put(EntityType.CAVE_SPIDER, 5.0);
        dropChances.put(EntityType.SILVERFISH, 5.0);
        dropChances.put(EntityType.ENDERMITE, 5.0);
        dropChances.put(EntityType.MAGMA_CUBE, 5.0);
        dropChances.put(EntityType.BLAZE, 5.0);
        dropChances.put(EntityType.GHAST, 5.0);
        dropChances.put(EntityType.HOGLIN, 5.0);
        dropChances.put(EntityType.ZOGLIN, 5.0);
        dropChances.put(EntityType.PIGLIN, 5.0);
        dropChances.put(EntityType.PIGLIN_BRUTE, 5.0);
        dropChances.put(EntityType.VINDICATOR, 5.0);
        dropChances.put(EntityType.EVOKER, 5.0);
        dropChances.put(EntityType.VEX, 5.0);
        dropChances.put(EntityType.PILLAGER, 5.0);
        dropChances.put(EntityType.RAVAGER, 5.0);
        dropChances.put(EntityType.SHULKER, 5.0);
        dropChances.put(EntityType.GUARDIAN, 5.0);
        dropChances.put(EntityType.ELDER_GUARDIAN, 5.0);

        // Passive mobs
        dropChances.put(EntityType.COW, 2.0);
        dropChances.put(EntityType.PIG, 2.0);
        dropChances.put(EntityType.SHEEP, 2.0);
        dropChances.put(EntityType.CHICKEN, 2.0);
        dropChances.put(EntityType.RABBIT, 2.0);
        dropChances.put(EntityType.FOX, 2.0);
        dropChances.put(EntityType.PANDA, 2.0);
        dropChances.put(EntityType.DOLPHIN, 2.0);
        dropChances.put(EntityType.BEE, 2.0);
        dropChances.put(EntityType.AXOLOTL, 2.0);
        dropChances.put(EntityType.CAMEL, 2.0);
        dropChances.put(EntityType.IRON_GOLEM, 2.0);
    }

    public boolean canDropHead(EntityType type) {
        return dropChances.containsKey(type);
    }

    public void dropHead(EntityType type, Location loc) {
        if (!canDropHead(type)) return;

        CompletableFuture.supplyAsync(() -> create3DHead(type), textureLoader)
                .thenAccept(head -> {
                    if (head != null) {
                        new BukkitRunnable() {
                            @Override
                            public void run() {
                                Item item = loc.getWorld().dropItem(loc, head);
                                item.setPickupDelay(20);
                                playDropEffects(loc);
                            }
                        }.runTask(plugin);
                    }
                });
    }

    private ItemStack create3DHead(EntityType type) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        if (head.getItemMeta() instanceof SkullMeta meta) {
            String texture = textures.getTexture(type);
            if (texture != null) {
                meta.setOwnerProfile(textures.createProfile(texture));
                head.setItemMeta(meta);
                return head;
            }
        }
        return null;
    }

    private void playDropEffects(Location loc) {
        // Play sound
        String soundName = "ENTITY_PLAYER_LEVELUP";
        try {
            Sound sound = Sound.valueOf(soundName);
            loc.getWorld().playSound(loc, sound, 1.0f, 1.0f);
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("Invalid sound name: " + soundName);
        }

        // Spawn particles
        loc.getWorld().spawnParticle(Particle.TOTEM, loc, 20, 0.5, 0.5, 0.5, 0.1);
    }

    public void soulbindHead(Player player, ItemStack head) {
        if (head.getType() != Material.PLAYER_HEAD) return;
        
        soulboundHeads.put(player.getUniqueId(), head.getItemMeta().getDisplayName());
        player.sendMessage(ChatColor.GREEN + "Head has been soulbound to you!");
    }

    public void releaseSoul(Player player) {
        if (soulboundHeads.remove(player.getUniqueId()) != null) {
            player.sendMessage(ChatColor.GREEN + "Your soul has been released!");
        } else {
            player.sendMessage(ChatColor.RED + "You don't have any soulbound heads!");
        }
    }

    public boolean isHeadSoulbound(Player player, ItemStack head) {
        if (head.getType() != Material.PLAYER_HEAD) return false;
        String headName = head.getItemMeta().getDisplayName();
        return soulboundHeads.getOrDefault(player.getUniqueId(), "").equals(headName);
    }

    public void shutdown() {
        textureLoader.shutdown();
    }
} 