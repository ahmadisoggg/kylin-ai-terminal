plugins {
    id("java")
    id("com.github.johnrengelman.shadow") version "8.1.1"
}

group = "com.headsteal"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    // For custom head textures
    implementation("com.mojang:authlib:1.5.25")
    // Paper API (targeting 1.21.5)
    compileOnly("io.papermc.paper:paper-api:1.21.5-R0.1-SNAPSHOT")
    // Other dependencies as needed
    implementation("org.bstats:bstats-bukkit:3.0.2")
    implementation("com.google.code.gson:gson:2.10.1")
    // Optional: Apache Commons for utilities
    implementation("org.apache.commons:commons-lang3:3.12.0")
    // Optional: Lombok for easier code (remove if not using)
    compileOnly("org.projectlombok:lombok:1.18.30")
    annotationProcessor("org.projectlombok:lombok:1.18.30")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(21))
}

tasks {
    processResources {
        filesMatching("plugin.yml") {
            expand(
                "version" to project.version
            )
        }
    }

    shadowJar {
        archiveBaseName.set("HeadSteal")
        archiveClassifier.set("")
        archiveVersion.set(project.version.toString())
        minimize()
    }

    build {
        dependsOn(shadowJar)
    }
} 